﻿using GlazkiSave.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlazkiSave.Utils
{
    class DatabaseContext
    {
        public static ModelDb db = new ModelDb();
    }
}
