﻿namespace GlazkiSave
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.logoLbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.nextPageBtn = new System.Windows.Forms.Label();
            this.fourthPageBtn = new System.Windows.Forms.Label();
            this.thirdPageBtn = new System.Windows.Forms.Label();
            this.secondPageBtn = new System.Windows.Forms.Label();
            this.firstPageBtn = new System.Windows.Forms.Label();
            this.previousPageBtn = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.descCheckBox = new System.Windows.Forms.CheckBox();
            this.filterComboBox = new System.Windows.Forms.ComboBox();
            this.sortComboBox = new System.Windows.Forms.ComboBox();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.changePriorityBtn = new System.Windows.Forms.FlowLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(249)))));
            this.panel1.Controls.Add(this.logoLbl);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1281, 100);
            this.panel1.TabIndex = 0;
            // 
            // logoLbl
            // 
            this.logoLbl.AutoSize = true;
            this.logoLbl.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.logoLbl.Location = new System.Drawing.Point(538, 33);
            this.logoLbl.Name = "logoLbl";
            this.logoLbl.Size = new System.Drawing.Size(211, 39);
            this.logoLbl.TabIndex = 1;
            this.logoLbl.Text = "Глазки-Save";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GlazkiSave.Properties.Resources.Глазки_save;
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(249)))));
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.nextPageBtn);
            this.panel2.Controls.Add(this.fourthPageBtn);
            this.panel2.Controls.Add(this.thirdPageBtn);
            this.panel2.Controls.Add(this.secondPageBtn);
            this.panel2.Controls.Add(this.firstPageBtn);
            this.panel2.Controls.Add(this.previousPageBtn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 598);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1281, 100);
            this.panel2.TabIndex = 1;
            // 
            // nextPageBtn
            // 
            this.nextPageBtn.AutoSize = true;
            this.nextPageBtn.Location = new System.Drawing.Point(1237, 45);
            this.nextPageBtn.Name = "nextPageBtn";
            this.nextPageBtn.Size = new System.Drawing.Size(22, 22);
            this.nextPageBtn.TabIndex = 0;
            this.nextPageBtn.Text = ">";
            // 
            // fourthPageBtn
            // 
            this.fourthPageBtn.AutoSize = true;
            this.fourthPageBtn.Location = new System.Drawing.Point(1209, 45);
            this.fourthPageBtn.Name = "fourthPageBtn";
            this.fourthPageBtn.Size = new System.Drawing.Size(21, 22);
            this.fourthPageBtn.TabIndex = 0;
            this.fourthPageBtn.Text = "4";
            // 
            // thirdPageBtn
            // 
            this.thirdPageBtn.AutoSize = true;
            this.thirdPageBtn.Location = new System.Drawing.Point(1181, 45);
            this.thirdPageBtn.Name = "thirdPageBtn";
            this.thirdPageBtn.Size = new System.Drawing.Size(21, 22);
            this.thirdPageBtn.TabIndex = 0;
            this.thirdPageBtn.Text = "3";
            // 
            // secondPageBtn
            // 
            this.secondPageBtn.AutoSize = true;
            this.secondPageBtn.Location = new System.Drawing.Point(1153, 45);
            this.secondPageBtn.Name = "secondPageBtn";
            this.secondPageBtn.Size = new System.Drawing.Size(21, 22);
            this.secondPageBtn.TabIndex = 0;
            this.secondPageBtn.Text = "2";
            // 
            // firstPageBtn
            // 
            this.firstPageBtn.AutoSize = true;
            this.firstPageBtn.Location = new System.Drawing.Point(1125, 45);
            this.firstPageBtn.Name = "firstPageBtn";
            this.firstPageBtn.Size = new System.Drawing.Size(21, 22);
            this.firstPageBtn.TabIndex = 0;
            this.firstPageBtn.Text = "1";
            // 
            // previousPageBtn
            // 
            this.previousPageBtn.AutoSize = true;
            this.previousPageBtn.Location = new System.Drawing.Point(1097, 45);
            this.previousPageBtn.Name = "previousPageBtn";
            this.previousPageBtn.Size = new System.Drawing.Size(22, 22);
            this.previousPageBtn.TabIndex = 0;
            this.previousPageBtn.Text = "<";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.descCheckBox);
            this.panel3.Controls.Add(this.filterComboBox);
            this.panel3.Controls.Add(this.sortComboBox);
            this.panel3.Controls.Add(this.searchTextBox);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1281, 58);
            this.panel3.TabIndex = 2;
            // 
            // descCheckBox
            // 
            this.descCheckBox.AutoSize = true;
            this.descCheckBox.Location = new System.Drawing.Point(707, 17);
            this.descCheckBox.Name = "descCheckBox";
            this.descCheckBox.Size = new System.Drawing.Size(157, 26);
            this.descCheckBox.TabIndex = 2;
            this.descCheckBox.Text = "По убыванию";
            this.descCheckBox.UseVisualStyleBackColor = true;
            this.descCheckBox.CheckedChanged += new System.EventHandler(this.descCheckBox_CheckedChanged);
            // 
            // filterComboBox
            // 
            this.filterComboBox.FormattingEnabled = true;
            this.filterComboBox.Items.AddRange(new object[] {
            "Все типы"});
            this.filterComboBox.Location = new System.Drawing.Point(1020, 15);
            this.filterComboBox.Name = "filterComboBox";
            this.filterComboBox.Size = new System.Drawing.Size(238, 30);
            this.filterComboBox.TabIndex = 3;
            this.filterComboBox.SelectedIndexChanged += new System.EventHandler(this.filterComboBox_SelectedIndexChanged);
            // 
            // sortComboBox
            // 
            this.sortComboBox.FormattingEnabled = true;
            this.sortComboBox.Items.AddRange(new object[] {
            "Наименование",
            "Приоритет"});
            this.sortComboBox.Location = new System.Drawing.Point(431, 15);
            this.sortComboBox.Name = "sortComboBox";
            this.sortComboBox.Size = new System.Drawing.Size(270, 30);
            this.sortComboBox.TabIndex = 1;
            this.sortComboBox.SelectedIndexChanged += new System.EventHandler(this.sortComboBox_SelectedIndexChanged);
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(14, 15);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(374, 31);
            this.searchTextBox.TabIndex = 0;
            this.searchTextBox.TextChanged += new System.EventHandler(this.searchTextBox_TextChanged);
            // 
            // changePriorityBtn
            // 
            this.changePriorityBtn.AutoScroll = true;
            this.changePriorityBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.changePriorityBtn.Location = new System.Drawing.Point(0, 158);
            this.changePriorityBtn.Name = "changePriorityBtn";
            this.changePriorityBtn.Size = new System.Drawing.Size(1281, 440);
            this.changePriorityBtn.TabIndex = 3;
            this.changePriorityBtn.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(117)))), ((int)(((byte)(238)))));
            this.button1.Location = new System.Drawing.Point(13, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(295, 43);
            this.button1.TabIndex = 1;
            this.button1.Text = "Изменить приоритет на...";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1281, 698);
            this.Controls.Add(this.changePriorityBtn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Информационная система \"Глазки-Save\"";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label logoLbl;
        private System.Windows.Forms.Label nextPageBtn;
        private System.Windows.Forms.Label fourthPageBtn;
        private System.Windows.Forms.Label thirdPageBtn;
        private System.Windows.Forms.Label secondPageBtn;
        private System.Windows.Forms.Label firstPageBtn;
        private System.Windows.Forms.Label previousPageBtn;
        private System.Windows.Forms.CheckBox descCheckBox;
        private System.Windows.Forms.ComboBox filterComboBox;
        private System.Windows.Forms.ComboBox sortComboBox;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.FlowLayoutPanel changePriorityBtn;
        private System.Windows.Forms.Button button1;
    }
}

