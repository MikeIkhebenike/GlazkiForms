﻿using GlazkiSave.Model;
using GlazkiSave.Utils;
using GlazkiSave.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GlazkiSave
{
    public partial class MainForm : Form
    {
        List<Agent> agents = new List<Agent>();
        public static List<AgentCard> selectedAgentCard = new List<AgentCard>();
        public MainForm()
        {
            InitializeComponent();
            agents = DatabaseContext.db.Agent.ToList();
            GenerateAgentCardList(agents);
        }

        void GenerateAgentCardList(List<Agent> agent)
        {
            foreach (var a in agent)
            {
                AgentCard card = new AgentCard();
                card.GenerateDataToAgentCard(a);
                changePriorityBtn.Controls.Add(card);
                card.Click += new System.EventHandler(this.Card_Click);
            }
        }

        private void Card_Click(object sender, EventArgs e)
        {
            AgentCard card = sender as AgentCard;
            if(card.BackColor == Color.White)
            {
                card.BackColor = Color.FromArgb(177,117,238);
                selectedAgentCard.Add(card);
            }
            else
            {
                card.BackColor = Color.White;
                selectedAgentCard.Remove(card);
            }

            if (selectedAgentCard.Count > 1)
            {
                changePriorityBtn.Visible = false;
            }

            else
            {
                changePriorityBtn.Visible = true;
            }
        }

        private void SortListView()
        {
            //Создана коллекция со списком агентов
            var listUpdate = DatabaseContext.db.Agent.ToList();

            //Фильтрация по типу агентов
            if (filterComboBox.SelectedIndex > 0)
            {

                listUpdate = listUpdate.Where(type => type.AgentType.Title == filterComboBox.SelectedItem
                .ToString()).ToList();
            }

            //Поиск по почте наименованию и номеру телефона
            if (searchTextBox.Text != "Введите для поиска" && !string.IsNullOrWhiteSpace(searchTextBox.Text.ToLower()))
            {
                listUpdate = listUpdate
                    .Where(x => x.Title.ToLower()
                    .Contains(searchTextBox.Text.ToLower()) ||
                    x.Phone.Contains(searchTextBox.Text) ||
                    x.Email.ToLower().Contains(searchTextBox.Text.ToLower())).ToList();
            }
            //Сортировка
            if (sortComboBox.Text == "Наименование")
            {

                //Сортировка по наименованию по возрастанию
                if (!descCheckBox.Checked)
                {
                    listUpdate = listUpdate.OrderBy(x => x.Title).ToList();
                }

                //Сортировка по наименованию по убыванию
                else
                {
                    listUpdate = listUpdate.OrderByDescending(x => x.Title).ToList();
                }
            }
            //Сортировка по приоритету по возрастанию
            if (sortComboBox.Text == "Приоритет")
            {
                if (!descCheckBox.Checked)
                {
                    listUpdate = listUpdate.OrderBy(x => x.Priority).ToList();
                }

                //Сортировка по приоритету по убыванию
                else
                {
                    listUpdate = listUpdate.OrderByDescending(x => x.Priority).ToList();
                }
            }
            changePriorityBtn.Controls.Clear();
            GenerateAgentCardList(listUpdate);
        }

        private void searchTextBox_TextChanged(object sender, EventArgs e)
        {
            if (searchTextBox.Text != "Введите для поиска")
            {

                changePriorityBtn.Controls.Clear();
                SortListView();
            }    
        }

        private void descCheckBox_CheckedChanged(object sender, EventArgs e)
        {

            changePriorityBtn.Controls.Clear();
            SortListView();
        }

        private void filterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            changePriorityBtn.Controls.Clear();
            SortListView();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            var allType = DatabaseContext.db.AgentType.Select(type => type.Title).ToList();
            filterComboBox.DataSource = allType;
            filterComboBox.SelectedIndex = 0;
            sortComboBox.SelectedIndex = 0;
        }

        private void sortComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            changePriorityBtn.Controls.Clear();
            SortListView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChangePriority changePriority = new ChangePriority();
            DialogResult dialogResult = DialogResult.OK;

        }
    }
}

